# Bitácora

> Se llena **en clase**, mientras se trabaja. Una fila por cada vez que se le pide algo a una
> herramienta. La columna que importa es la última.

| # | Fecha | Qué pedí | Qué devolvió | Qué corregí | Por qué |
|---|---|---|---|---|---|
| 1 |  |  |  |  |  |
| 2 |  |  |  |  |  |
| 3 |  |  |  |  |  |
| 4 |  |  |  |  |  |
| 5 |  |  |  |  |  |

**Cómo se llena bien.**
«Qué corregí» no es «nada». Si de verdad no se corrigió nada, la fila dice *«no corregí nada
y aquí está por qué eso me preocupa»*. Una bitácora sin correcciones no demuestra que la
herramienta acertó: demuestra que no se leyó.
