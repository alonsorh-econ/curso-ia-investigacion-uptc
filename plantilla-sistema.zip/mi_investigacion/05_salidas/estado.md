# Estado del sistema

> Lo último de la sesión. Se le pide a la herramienta que lea lo que uno acaba de escribir
> y diga **qué falta**, no qué está bien.

## El prompt que se usó
```
Te voy a pegar cuatro archivos que escribí hoy: mi contexto, mi hipótesis, el
interrogatorio con mis respuestas, y lo que sé de los datos.

Dime tres cosas, en este orden:
1. Cuál de las cuatro piezas está más floja, y por qué.
2. Qué información me falta para poder dar el siguiente paso.
3. Una sola tarea concreta para hacer antes de la próxima sesión.

No me resumas lo que ya escribí. No me elogies. No inventes datos que no estén
en lo que te pegué.
```

## Lo que devolvió
[…]

## La tarea que quedó para el jueves
[…]
