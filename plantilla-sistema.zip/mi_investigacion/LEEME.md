# Mi sistema de investigación

> Plantilla del curso **IA aplicada a la investigación: de las tareas al sistema**
> CENES · UPTC · septiembre de 2026 · Alonso Ramírez Hernández

Esta carpeta no es un archivador. Es **la memoria de una investigación**: cada paso que se da
deja un archivo, y el archivo siguiente se escribe leyendo el anterior. Eso es todo lo que
significa «sistema».

## La regla, en una frase

**Nada importante vive dentro de un chat.** Lo que sirve se copia a un archivo de esta carpeta.
Un chat se pierde, se borra, o el modelo cambia y ya no dice lo mismo. Un archivo se queda.

## Las seis casillas

| Carpeta | Qué guarda | Paso del martes |
|---|---|---|
| `00_contexto/` | Quién soy, qué estudio, qué sé del terreno. Lo que la herramienta necesita saber **antes** de responder. | 1 · Dominio |
| `01_ideas/` | La inquietud, la hipótesis, las formulaciones alternativas que se probaron. | 2 · Intuición |
| `02_decision/` | El interrogatorio, las objeciones respondidas, y **por qué se descartó lo que se descartó**. | 3 · Valoración · 6 · Metodología |
| `03_literatura/` | La tabla de evidencia, verificada contra DOI. | 4 · Literatura |
| `04_datos/` | Qué dato hace falta, quién lo tiene, qué se pudo bajar. | 5 · Datos |
| `05_salidas/` | Lo que se entrega: el esqueleto, la figura, la página. | 7 · Esqueleto |

## Los dos archivos de la raíz

- **`CONTEXTO.md`** — se pega al principio de **cada** conversación nueva. Es lo que reemplaza a
  «proyectos», «Gems» o cualquier función de pago: el contexto lo carga uno, a mano, y por eso
  funciona igual en ChatGPT, en Claude y en Gemini, en su versión gratuita.
- **`BITACORA.md`** — cuatro columnas: qué pedí · qué devolvió · qué corregí · por qué.
  Se llena **mientras** se trabaja, no después. Vale 20 % de la nota.

## Cómo se nombra un archivo

`aaaa-mm-dd_tema_corto.md` — por ejemplo `2026-09-03_hipotesis_v1.md`.
La fecha adelante hace que el computador los ordene solo. **Nunca `final_v2_bueno_DEFINITIVO`.**
