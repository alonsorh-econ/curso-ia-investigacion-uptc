# La hipótesis

> **Paso 2 del martes · Intuición.** La hipótesis la trae uno; a la máquina se le pide que
> la **afile**, no que la invente.

## El prompt que se usó
```
[pegar el prompt tal como se escribió]
```

## Lo que devolvió, sin editar
[…]

## La hipótesis, con sus tres partes
- **Sujeto:** […]
- **Tratamiento (X):** […]
- **Resultado (Y):** […]
- **En una frase:** […]

## El mecanismo que la haría cierta
[…]

## Dos formulaciones alternativas que se descartaron, y por qué
| Formulación | Por qué se descartó |
|---|---|
| […] | […] |
| […] | […] |
