# Tabla de evidencia

> **Paso 4 · Literatura.** Se llena el **jueves 3 de septiembre**, en la sesión 2.
> Por ahora solo se crea el archivo y se deja el sobre sellado adentro.

## El sobre sellado
> Las cinco referencias que la herramienta dio el martes, **sin verificar**. Se pegan aquí
> tal como salieron y no se tocan hasta el jueves.

1. […]
2. […]
3. […]
4. […]
5. […]

## La tabla (jueves)
| Autor y año | Título | Revista | DOI | ¿Existe? | Qué le dice a mi pregunta |
|---|---|---|---|---|---|
|  |  |  |  |  |  |
