# El interrogatorio

> **Paso 3 del martes · Valoración.** El modo CRITICA. La máquina no genera aquí: objeta.
> **Una objeción sin respuesta escrita no cuenta.**

## El prompt que se usó
```
[pegar el prompt tal como se escribió]
```

## Las tres objeciones y sus respuestas

### Objeción 1 — […]
**Qué tendría que mostrar para tumbarla:** […]
**Mi respuesta:** […]

### Objeción 2 — […]
**Qué tendría que mostrar para tumbarla:** […]
**Mi respuesta:** […]

### Objeción 3 — […]
**Qué tendría que mostrar para tumbarla:** […]
**Mi respuesta:** […]

## La objeción que la máquina NO encontró
[…] *(La local. La que uno sabe por estar aquí. Si aparece una, este archivo ya valió la pena.)*

## ¿Me elogió la pregunta aunque el prompt lo prohibía?
[ ] sí — copiar la frase: […]
[ ] no
