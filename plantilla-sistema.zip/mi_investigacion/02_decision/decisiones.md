# Registro de decisiones

> Una línea por decisión. **Se escribe cuando se decide, no al final.** Es el archivo que
> permite que otro —o uno mismo en tres semanas— entienda por qué el trabajo tomó este camino
> y no otro.

| Fecha | Qué se decidió | Qué se descartó | Por qué |
|---|---|---|---|
|  |  |  |  |
|  |  |  |  |

---
**La columna «qué se descartó» es la que casi nadie llena.** En el proyecto que se mostró en
clase, esa casilla quedó en blanco y el docente lo enseñó con las casillas vacías puestas.
