# Lo que sé del terreno

> **Paso 1 del martes · Dominio.** Esto NO se le pregunta a la máquina: se escribe a mano.
> Es lo único del sistema que la herramienta no puede producir, y es lo que la vuelve útil.

## El tema, en una frase
[…]

## Tres cosas que sé porque estoy aquí y el modelo no puede saber
1. […] *(ejemplo: «esa base la administra la Secretaría de Hacienda del departamento y no la entrega por fuera»)*
2. […] *(ejemplo: «en Boyacá esa variable dejó de medirse en 2022»)*
3. […] *(ejemplo: «el grupo de la UPTC ya trabajó algo parecido en 2023 y no se publicó»)*

## Quién decide algo distinto si esto se responde
[…]

---
*Si no se llenan los tres puntos de arriba, la sesión completa se vuelve una conversación
genérica. Es el bloque que separa una investigación de un resumen.*
