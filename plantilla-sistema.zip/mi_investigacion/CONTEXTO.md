# CONTEXTO — se pega al principio de cada conversación

> Llenar una vez. Actualizar cuando cambie algo. **Pegar completo** al abrir cada chat nuevo,
> antes de la primera pregunta. Es el archivo que hace que la herramienta deje de responderle
> a un desconocido.

---

**Quién soy.** Soy estudiante de [programa] en la UPTC, en el semillero [nombre del semillero].
Estoy en [semestre / año].

**Qué estoy investigando.** [Una frase. La inquietud, no la pregunta todavía.]

**Qué sé del terreno que la herramienta no puede saber.**
[Aquí van las tres o cuatro cosas que uno sabe por estar donde está: qué entidad administra
ese dato y si lo entrega, quién ya trabajó el tema en la región, qué variable no se mide en
Boyacá, qué pasó en 2023 que rompió la serie. **Este bloque es el que vale.**]

**Con qué cuento.** [Datos a los que tengo acceso real · tiempo disponible · si sé o no
programar · qué software tengo instalado.]

**Cómo quiero que me respondas.**
- En español, y sin elogiarme la pregunta.
- Si no sabes algo, dilo. **No completes con lo que suene bien.**
- Cuando cites un trabajo, dame autor, año, título, revista y DOI, y adviérteme si no estás
  seguro de que exista.
- No me propongas temas nuevos. Trabaja sobre el mío.

---

*Última actualización: [fecha]*
