# Los datos

> **Paso 5 · Datos.** La pregunta no es «¿hay datos?» sino **«¿qué variable exactamente, y
> quién la tiene?»**

| Variable | Para qué la necesito | Quién la tiene | ¿Es pública? | ¿La tengo ya? |
|---|---|---|---|---|
| Y (resultado) | […] | […] | […] | […] |
| X (tratamiento) | […] | […] | […] | […] |
| Controles | […] | […] | […] | […] |

## La limitante que ya se ve
[…] *(En el demo del martes: SECOP tenía la variable de resultado y **no** la de tratamiento.
Esa frase —«tengo la mitad»— es un hallazgo, no un fracaso.)*
