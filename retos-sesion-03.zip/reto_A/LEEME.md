# Reto A · 20 minutos

**Base:** `saber11_bogota_por_anio.csv` — 15 filas, una por año.
Resultados de la prueba Saber 11 en Bogotá, 2010–2024. Cada fila trae cuántos estudiantes
presentaron y el puntaje promedio de ese año.

| Columna | Qué es |
|---|---|
| `anio` | año de aplicación |
| `estudiantes` | cuántos presentaron ese año en Bogotá |
| `puntaje_promedio` | promedio del puntaje global |

---

## La consigna

1. **Corran el descriptivo.** Grafiquen `puntaje_promedio` contra `anio`. Nada más.
2. **Miren la figura y digan qué encontraron.** Escríbanlo en una frase, como si fuera el
   hallazgo de un paper.
3. **Ahora encuentren qué está mal.** Hay algo en esta base que hace que esa frase sea falsa.
4. **Escriban en UNA línea qué decisión de muestra tomarían** para que el descriptivo sea
   honesto.

> ⚠️ **No hay que arreglarlo. Hay que detectarlo.**
> Y ojo: el código no tiene ningún error. Corre, no da advertencias y produce un número.

---

## Lo que se entrega

Tres renglones en su `FUENTES.md`, en `04_datos/`:

```
Fuente: Saber 11 Bogotá 2010–2024 (reto A del curso)
Fecha de descarga: 5-sep-2026
Filtro aplicado: —
Decisión de muestra: <su línea>
```

---

## Una pista, solo si llevan diez minutos atascados

> Un promedio solo se puede comparar en el tiempo si **la regla para calcularlo** no cambió.
> Pregúntenle a la fuente qué le pasó a la prueba entre 2013 y 2015.

---

*Los datos son reales: microdato del ICFES agregado a nivel de año. No hay ningún dato
inventado ni ninguna trampa sembrada a propósito — es exactamente lo que sale de la fuente.*
