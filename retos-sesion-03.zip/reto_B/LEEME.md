# Reto B · 20 minutos

**Base:** `saber11_bogota_por_periodo.csv` — 20 filas, una por período de aplicación.
Resultados de Saber 11 en Bogotá, 2015–2024. Cada año tiene **dos períodos**.

| Columna | Qué es |
|---|---|
| `periodo` | año y semestre de aplicación (`2015-1`, `2015-2`, …) |
| `estudiantes` | cuántos presentaron en ese período |
| `puntaje_promedio` | promedio del puntaje global |
| `pct_oficial` | porcentaje de estudiantes de colegio oficial |

---

## La consigna

1. **Corran el descriptivo.** Saquen el promedio por año —el promedio de los dos períodos—
   y grafíquenlo contra el año.
2. **Miren 2021.** Es el año más alto de la serie. Escriban en una frase qué explicaría ese
   salto en plena pandemia.
3. **Ahora encuentren qué está mal.** Miren las otras dos columnas.
4. **Escriban en UNA línea qué decisión de muestra tomarían.**

> ⚠️ **No hay que arreglarlo. Hay que detectarlo.**
> Aquí la escala no cambió: de 2015 en adelante todo está en la misma escala de 100 a 500.
> Lo que pasa es otra cosa.

---

## Lo que se entrega

Tres renglones en su `FUENTES.md`, en `04_datos/`, con su decisión de muestra.

---

## Una pista, solo si llevan diez minutos atascados

> ¿Cuántos estudiantes presentaron en `2021-1` y cuántos en `2021-2`?
> ¿Y qué proporción de cada grupo viene de colegio oficial?
> Si esas dos preguntas dan respuestas muy distintas, **no está mirando un año: está
> mirando dos poblaciones distintas pegadas con cinta.**

---

*Los datos son reales: microdato del ICFES agregado a nivel de período. Nada sembrado
a propósito.*
