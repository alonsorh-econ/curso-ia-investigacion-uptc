# Reto C · 20 minutos

**Base:** `secop_municipios_2021_2025.csv` — 2.706 filas: un municipio por año.
Contratación pública municipal en Colombia, 2021–2025, construida desde SECOP II.

| Columna | Qué es |
|---|---|
| `codmpio` · `municipio` · `departamento` | identificación del municipio |
| `anio` | año |
| `contratos` | cuántos contratos reportó ese municipio ese año |
| `part_directa` | proporción de esos contratos hechos por contratación directa (0 a 1) |

---

## La consigna

1. **Corran el descriptivo.** Saquen la **mediana** de `part_directa` por año y grafíquenla.
2. **Miren la pendiente.** Va de casi cero a más de 0,7 en cinco años. Escriban en una frase
   qué titular de prensa saldría de ahí.
3. **Ahora encuentren qué está mal.** Cuenten **cuántos municipios distintos** hay en cada año.
4. **Escriban en UNA línea qué decisión de muestra tomarían.**

> ⚠️ **No hay que arreglarlo. Hay que detectarlo.**
> El código está bien. La base está bien. El problema está en la pregunta que uno le hizo.

---

## Lo que se entrega

Tres renglones en su `FUENTES.md`, en `04_datos/`, con su decisión de muestra.

---

## Una pista, solo si llevan diez minutos atascados

> Un promedio que cambia puede cambiar por dos razones: porque **los mismos** cambiaron,
> o porque **cambió quiénes son**. Repitan el descriptivo sobre el subconjunto de
> municipios que aparecen en **los cinco años**, y luego sobre los que además reportan
> al menos 50 contratos en cada uno de los cinco. Comparen las tres series.

---

*Los datos son reales y salen de un análisis propio: el panel municipio–año de SECOP II
que se usa en el bloque M4 de esta misma sesión.*
